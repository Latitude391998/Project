package project.entity;

public enum Status {
	OPEN, PROCESSING, COMPLETE
}
