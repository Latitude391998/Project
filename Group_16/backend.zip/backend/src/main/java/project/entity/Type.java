package project.entity;

public enum Type {
	MAINTENANCE, REPAIR
}
