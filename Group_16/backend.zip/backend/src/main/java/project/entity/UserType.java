package project.entity;

public enum UserType {
	CUSTOMER, MANUFACTURER
}
