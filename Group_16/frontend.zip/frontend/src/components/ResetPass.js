const ResetPass = () => {
    return(
        <div>
            hello
        </div>
    )
}

export default ResetPass;